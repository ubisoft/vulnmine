# List of things "To Do"


* 2017-9-19 Provide Python3 support
* 2017-9-19 Develop a GUI Interface?

